package com.example.cooking

import RecipeAdapter
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class RecipeListActivity : AppCompatActivity() {

    private lateinit var recipesRecyclerView: RecyclerView
    private lateinit var noResultsTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_list)

        recipesRecyclerView = findViewById(R.id.recipesRecyclerView)
        noResultsTextView = findViewById(R.id.noResultsTextView)

        val ingredients = intent.getStringArrayListExtra("INGREDIENTS_LIST") ?: arrayListOf()
        val recipes = findMatchingRecipes(ingredients)

        if (recipes.isEmpty()) {
            noResultsTextView.visibility = View.VISIBLE
        } else {
            noResultsTextView.visibility = View.GONE
            recipesRecyclerView.layoutManager = LinearLayoutManager(this)
            recipesRecyclerView.adapter = RecipeAdapter(recipes) { selectedRecipe ->
                val intent = Intent(this, RecipeDetailActivity::class.java)
                intent.putExtra("RECIPE", selectedRecipe)
                startActivity(intent)
            }
        }
    }

    private fun findMatchingRecipes(ingredients: List<String>): List<Recipe> {
        // If no ingredients are provided, return all recipes
        if (ingredients.isEmpty()) {
            return RecipeData.recipes
        }

        val userIngredientsSet = ingredients.toSet()

        // Filter recipes that match all provided ingredients
        return RecipeData.recipes.filter { recipe ->
            recipe.ingredients.toSet().all { it in userIngredientsSet }
        }
    }
}
