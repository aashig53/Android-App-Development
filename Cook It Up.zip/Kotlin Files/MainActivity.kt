package com.example.cooking

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var ingredientInput: EditText
    private lateinit var addIngredientButton: Button
    private lateinit var findRecipesButton: Button
    private lateinit var chipGroupIngredients: ChipGroup
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    private lateinit var toolbar: Toolbar
    private val ingredientsList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views
        ingredientInput = findViewById(R.id.ingredientInput)
        addIngredientButton = findViewById(R.id.addIngredientButton)
        findRecipesButton = findViewById(R.id.findRecipesButton)
        chipGroupIngredients = findViewById(R.id.chipGroupIngredients)

        // Initialize the DrawerLayout and ActionBarDrawerToggle
        drawerLayout = findViewById(R.id.drawerLayout)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        actionBarDrawerToggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.open,
            R.string.close
        )

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        // Set up NavigationView item selection
        val navigationView: NavigationView = findViewById(R.id.navigationView)
        navigationView.setNavigationItemSelectedListener { menuItem ->
            handleNavigationItem(menuItem)
            true
        }

        // Set Click Listeners
        addIngredientButton.setOnClickListener {
            addIngredient()
        }

        findRecipesButton.setOnClickListener {
            findRecipes()
        }
    }

    // Handle navigation item selection
    private fun handleNavigationItem(menuItem: MenuItem) {
        when (menuItem.itemId) {
            R.id.menu_show_all_recipes -> {
                val intent = Intent(this, RecipeListActivity::class.java)
                intent.putStringArrayListExtra("INGREDIENTS_LIST", ArrayList())
                startActivity(intent)
            }
            R.id.menu_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
            }
        }
        drawerLayout.closeDrawers() // Close drawer after item is selected
    }

    // Function to add ingredient as a chip
    private fun addIngredient() {
        val ingredient = ingredientInput.text.toString().trim()
        if (ingredient.isNotEmpty() && !ingredientsList.contains(ingredient)) {
            ingredientsList.add(ingredient)
            createChip(ingredient)
            ingredientInput.text.clear()
        } else {
            Toast.makeText(this, "Enter a valid ingredient", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to create a Chip for each ingredient
    private fun createChip(ingredient: String) {
        val chip = Chip(this).apply {
            text = ingredient
            isCloseIconVisible = true
            setOnCloseIconClickListener {
                chipGroupIngredients.removeView(this)
                ingredientsList.remove(ingredient)
            }
        }
        chipGroupIngredients.addView(chip)
    }

    // Function to find recipes based on added ingredients
    private fun findRecipes() {
        if (ingredientsList.isNotEmpty()) {
            // Navigate to RecipeListActivity with ingredients
            val intent = Intent(this, RecipeListActivity::class.java)
            intent.putStringArrayListExtra("INGREDIENTS_LIST", ArrayList(ingredientsList))
            startActivity(intent)
        } else {
            Toast.makeText(this, "Please add at least one ingredient", Toast.LENGTH_SHORT).show()
        }
    }

    // Override the onOptionsItemSelected to toggle drawer when icon is clicked
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}
