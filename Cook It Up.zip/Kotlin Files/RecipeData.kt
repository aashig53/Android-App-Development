package com.example.cooking

object RecipeData {
    val recipes = listOf(
        Recipe(
            name = "Pancakes",
            ingredients = listOf("flour", "milk", "egg"),
            cookingTime = "15 minutes",
            process = """
                
                
                1. In a large bowl, whisk together 1 cup of flour, 1 tablespoon of sugar, 1 teaspoon of baking powder, and a pinch of salt.
                    
                2. In another bowl, whisk together 1 cup of milk, 1 large egg, and 1 tablespoon of melted butter until smooth.
                    
                3. Pour the wet ingredients into the dry ingredients and stir gently until combined (do not overmix; lumps are okay).
                    
                4. Heat a non-stick skillet over medium heat and add a little butter or oil to coat the pan.
                    
                5. Pour 1/4 cup of batter onto the skillet for each pancake.
                
                6. Cook for 2-3 minutes, or until bubbles form on the surface and the edges look set, then flip and cook for another 1-2 minutes until golden brown.
                    
                7. Serve hot with your favorite toppings, like maple syrup, butter, or fresh berries.
                    
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.pancake
        ),
        Recipe(
            name = "Chocolate Cake",
            ingredients = listOf("flour", "cocoa powder", "egg", "milk"),
            cookingTime = "30 minutes",
            process = """
                
                
                1. Preheat your oven to 350°F (175°C) and grease a 9x13 inch baking pan.
                
                2. In a large bowl, mix together 1 3/4 cups of flour, 3/4 cup of cocoa powder, 2 cups of sugar, 1 1/2 teaspoons of baking powder, and 1/2 teaspoon of salt until well combined.
                
                3. In another bowl, cream 1/2 cup of softened butter until smooth, then add 2 large eggs, 1 cup of milk, and 2 teaspoons of vanilla extract. Beat until well combined.
                
                4. Gradually add the wet ingredients to the dry ingredients, mixing until just combined (do not overmix).
                
                5. Pour the batter into the prepared baking pan and smooth the top.
                
                6. Bake in the preheated oven for about 25-30 minutes, or until a toothpick inserted into the center comes out clean.
                
                7. Allow the cake to cool in the pan for 10 minutes, then transfer it to a wire rack to cool completely.
                
                8. Frost with your favorite chocolate frosting once the cake is cool.
                
            """.trimIndent(),
            servings = 8,
            photoResId = R.drawable.cake
        ),
        Recipe(
            name = "Vegetable Stir-Fry",
            ingredients = listOf("bell peppers", "broccoli", "carrots", "soy sauce", "garlic", "ginger", "olive oil", "sesame seeds"),
            cookingTime = "15 minutes",
            process = """
                
                
                1. Heat 2 tablespoons of olive oil in a large skillet or wok over medium-high heat.
                
                2. Add 3 minced garlic cloves and 1 teaspoon of minced ginger; sauté for 30 seconds.
                
                3. Add 1 cup each of chopped bell peppers, broccoli florets, and sliced carrots.
                
                4. Stir-fry the vegetables for about 5-7 minutes until they are tender-crisp.
                
                5. Pour in 1/4 cup of soy sauce and stir well to coat the vegetables.
                
                6. Cook for an additional 2-3 minutes, then remove from heat.
                
                7. Serve hot, garnished with sesame seeds.
                
            """.trimIndent(),
            servings = 4,
            photoResId = R.drawable.vegetable_stir_fry
        ),
        Recipe(
            name = "Veggie Tacos",
            ingredients = listOf("corn tortillas", "black beans", "avocado", "tomato", "red onion", "cilantro", "lime", "sour cream"),
            cookingTime = "20 minutes",
            process = """
                
                
                1. In a bowl, mash 1 ripe avocado with the juice of 1 lime.
                
                2. Warm 4 corn tortillas in a skillet over medium heat.
                
                3. In each tortilla, add a layer of black beans (1 cup), mashed avocado, diced tomato, and chopped red onion.
                
                4. Top with fresh cilantro and a dollop of sour cream.
                
                5. Serve immediately with lime wedges.
                
        """.trimIndent(),
            servings = 4,
            photoResId = R.drawable.tacos
        ),
        Recipe(
            name = "Garlic Butter Pasta",
            ingredients = listOf("spaghetti", "butter", "garlic", "parsley", "salt", "pepper"),
            cookingTime = "15 minutes",
            process = """
                
                
                1. Cook 200g of spaghetti according to package instructions; drain and set aside.
                
                2. In a pan, melt 4 tablespoons of butter over medium heat.
                
                3. Add 3 minced garlic cloves and sauté for about 1 minute until fragrant.
                
                4. Toss the cooked spaghetti in the garlic butter, adding chopped parsley, salt, and pepper to taste.
                
                5. Serve hot.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.garlic_pasta
        ),
        Recipe(
            name = "Avocado Toast",
            ingredients = listOf("bread", "avocado", "pepper"),
            cookingTime = "5 minutes",
            process = """
                
                
                1. Toast 2 slices of bread until golden brown.
                
                2. In a bowl, mash 1 ripe avocado with salt and pepper to taste.
                
                3. Spread the mashed avocado on the toasted bread.
                
                4. Serve immediately, optionally topped with chili flakes or lemon juice.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.vegan_avocado_toast
        ),
        Recipe(
            name = "Cucumber Sandwiches",
            ingredients = listOf("bread", "cream cheese", "cucumber"),
            cookingTime = "10 minutes",
            process = """
        
        
                1. Spread cream cheese on a slice of bread.
        
                2. Thinly slice a cucumber and arrange the slices on the cream cheese.
        
                3. Top with another slice of bread.
        
                4. Cut the sandwich into quarters and serve.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.cucumber
        ),
        Recipe(
            name = "Simple Pasta",
            ingredients = listOf("pasta", "olive oil", "garlic"),
            cookingTime = "15 minutes",
            process = """
                
                
                1. Cook pasta according to package instructions until al dente.
        
                2. In a pan, heat olive oil and sauté minced garlic until fragrant.
        
                3. Drain the pasta and add it to the pan.
        
                4. Toss to coat and season with salt to taste.
        
                5. Serve hot.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.pasta
        ),
        Recipe(
            name = "Garlic Roasted Potatoes",
            ingredients = listOf("potatoes", "garlic", "olive oil"),
            cookingTime = "25 minutes",
            process = """
        
        
                1. Preheat oven to 400°F (200°C).
        
                2. Cut potatoes into wedges and place them in a baking dish.
        
                3. Add minced garlic, olive oil, and salt. Toss to coat.
        
                4. Roast for 20-25 minutes until golden brown and crispy.
        
                5. Serve as a side dish.
                
            """.trimIndent(),
            servings = 4,
            photoResId = R.drawable.garlic_potato
        ),
        Recipe(
            name = "Dal Tadka",
            ingredients = listOf("lentils", "onion", "tomato", "garlic"),
            cookingTime = "30 minutes",
            process = """
                
                
                1. Cook lentils until soft; set aside.
        
                2. In a pan, heat oil and sauté chopped onion, tomato, and garlic.
        
                3. Add cooked lentils and spices; mix well and cook for 5 minutes.
        
                4. Serve hot with rice or roti.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.dal_tadka
        ),
        Recipe(
            name = "Cucumber Raita",
            ingredients = listOf("yogurt", "cucumber", "salt", "cumin powder"),
            cookingTime = "5 minutes",
            process = """
        
        
                1. Grate cucumber and mix it into yogurt.
        
                2. Add salt and cumin powder; mix well.
        
                3. Serve chilled as a side dish.
                
            """.trimIndent(),
            servings = 2,
            photoResId = R.drawable.cucumber_raita
        )
    )
}
