package com.example.cooking

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Recipe(
    val name: String,
    val ingredients: List<String>,
    val cookingTime: String,
    val process: String,
    val servings: Int,
    val photoResId: Int
) : Parcelable
