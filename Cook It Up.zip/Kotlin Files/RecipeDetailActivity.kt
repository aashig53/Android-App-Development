package com.example.cooking

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RecipeDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_detail)

        // Initialize views
        val recipeImageView: ImageView = findViewById(R.id.recipeImageView)
        val recipeTitleTextView: TextView = findViewById(R.id.recipeTitleTextView)
        val recipeIngredientTextView: TextView = findViewById(R.id.recipeIngredientsTextView)
        val recipeServingsTextView: TextView = findViewById(R.id.recipeServingsTextView)
        val recipeCookingTimeTextView: TextView = findViewById(R.id.recipeCookingTimeTextView)
        val recipeProcessTextView: TextView = findViewById(R.id.recipeProcessTextView)

        // Retrieve recipe data from intent
        val recipe = intent.getParcelableExtra<Recipe>("RECIPE")
        if (recipe != null) {
            // Populate views with recipe data
            recipeImageView.setImageResource(recipe.photoResId)
            recipeTitleTextView.text = recipe.name
            recipeIngredientTextView.text = "Ingredients: ${recipe.ingredients}"
            recipeServingsTextView.text = "Servings: ${recipe.servings}"
            recipeCookingTimeTextView.text = "Cooking Time: ${recipe.cookingTime}"
            recipeProcessTextView.text = "Process: ${recipe.process}"
        }
    }
}
