import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cooking.R
import com.example.cooking.Recipe

class RecipeAdapter(
    private val recipes: List<Recipe>,
    private val onItemClick: (Recipe) -> Unit
) : RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recipe, parent, false)
        return RecipeViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val recipe = recipes[position]
        holder.recipeTitleTextView.text = recipe.name
        holder.recipeIngredientsTextView.text = "Ingredients: " + recipe.ingredients.joinToString(", ")
        holder.recipeCookingTimeTextView.text = "Cooking Time: " + recipe.cookingTime
        holder.recipeServingsTextView.text = "Servings: " + recipe.servings.toString()

        holder.recipeImageView.setImageResource(recipe.photoResId)

        holder.itemView.setOnClickListener { onItemClick(recipe) }
    }

    override fun getItemCount(): Int = recipes.size

    inner class RecipeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val recipeTitleTextView: TextView = view.findViewById(R.id.recipeTitleTextView)
        val recipeIngredientsTextView: TextView = view.findViewById(R.id.recipeIngredientsTextView)
        val recipeCookingTimeTextView: TextView = view.findViewById(R.id.recipeCookingTimeTextView)
        val recipeServingsTextView: TextView = view.findViewById(R.id.recipeServingsTextView)
        val recipeImageView: ImageView = view.findViewById(R.id.recipeImageView)
    }
}
