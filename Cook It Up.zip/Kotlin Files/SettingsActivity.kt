package com.example.cooking

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class SettingsActivity : AppCompatActivity() {

    private lateinit var darkModeSwitch: Switch
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE)
        darkModeSwitch = findViewById(R.id.darkModeSwitch)

        // Set initial switch state based on saved preferences
        darkModeSwitch.isChecked = sharedPreferences.getBoolean("DARK_MODE", false)

        // Set the current mode based on saved preference
        if (darkModeSwitch.isChecked) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        // Toggle dark mode
        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            // Save dark mode setting
            saveDarkModeSetting(isChecked)
        }
    }

    // Save dark mode setting
    private fun saveDarkModeSetting(isEnabled: Boolean) {
        val editor = sharedPreferences.edit()
        editor.putBoolean("DARK_MODE", isEnabled)
        editor.apply()
    }
}
